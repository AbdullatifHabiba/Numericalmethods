export interface Point {
  x:number;
  y:number;
  rootx:number;
  rooty:number;

// netwon
  yd:number;
  //fixed
  gx:number;

}
